# codigos-sql
 alguns codigos para ajudar no sql
