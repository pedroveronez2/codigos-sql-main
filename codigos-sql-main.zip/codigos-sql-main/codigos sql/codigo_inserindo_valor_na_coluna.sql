-- use nome_da_tabela;

-- insert into nome_da_tabela (nome_da_coluna) values ('iniserir_valor');


