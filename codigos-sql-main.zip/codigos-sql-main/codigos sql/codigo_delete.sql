USE nome_banco_dados;

-- delete from nome_tabela where numero_id = 7;

SELECT * from nome_tabela;