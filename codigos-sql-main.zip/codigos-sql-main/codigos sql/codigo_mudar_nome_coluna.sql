ALTER TABLE `nome_tabela`.`nome_tabela` 
CHANGE COLUMN `coluna_antiga` `coluna_nova` dados da coluna ;