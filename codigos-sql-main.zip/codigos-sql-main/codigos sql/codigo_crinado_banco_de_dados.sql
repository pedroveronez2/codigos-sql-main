create database cadastro
default character set utf8
default collate utf8_general_ci;
