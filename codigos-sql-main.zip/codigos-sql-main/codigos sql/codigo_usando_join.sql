-- primeiro criar uma coluna com uma chave estrangeira (foreign key) para referenciar a outra tabela atraves de um numero de referencia
ALTER TABLE nome_da_tabela ADD COLUMN nome_da_coluna int; 
alter table nome_databela add foreign key (nome_coluna) references nome_outra_tabela(coluna_da_outra_tabela);


-- codigo referenciando

select nome_tabela.nome_coluna,  nome_outra_tabela.coluna_da_outra_tabela from nome_tabela join nome_outra_tabela
on nome_tabela.nome_coluna = nome_outra_tabela.id_coluna_da_outra_tabela;


-- ex:

-- use trabalho;

-- select * from pessoas;
-- select * from profissoes;
-- alter table pessoas add foreign key (trabalho) references profissoes(id);

-- SELECT nome, trabalho from pessoas;

-- select pessoas.nome, profissoes.profissao from pessoas join profissoes on pessoas.trabalho = profissoes.id;