use nome_banco_dados;

-- update nome_tabela set nome_coluna = 'inserir valor' where id_da_coluna = 'numero do id';

select * from nome_tabela